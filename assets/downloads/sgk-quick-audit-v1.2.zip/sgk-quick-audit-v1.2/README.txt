SpaceGhostKilla // Cloud Security Quick Audit v1.2: companion scripts

Run these instead of copying commands out of the PDF: PDF viewers can drop the
indentation that the embedded Python needs.

1. Open AWS CloudShell or Azure Cloud Shell (or a Linux shell with AWS CLI v2,
   Azure CLI, jq, python3).
2. Unzip into an empty, private directory and run setup-a-aws.sh first.
   Checks 02, 04 and 05 read credential-report.csv from the current directory.
3. Run a check with:  bash check-02-aws.sh
4. Delete credential-report.csv and any saved output when the audit is closed.

Only assess systems you own or are explicitly authorized to test.
