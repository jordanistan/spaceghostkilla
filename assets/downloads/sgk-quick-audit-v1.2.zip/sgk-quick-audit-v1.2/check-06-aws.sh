#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-06-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

(
  set -o pipefail
  fns=$(aws lambda list-functions --query 'Functions[].FunctionName' --output text) || exit 1
  for f in $fns; do
    names=$(aws lambda get-function-configuration --function-name "$f" \
      --query 'keys(Environment.Variables || `{}`)' --output text) \
      || { echo "UNKNOWN: $f (could not read configuration)"; continue; }
    printf '%s\n' $names | grep -iE 'key|secret|token|passw|cred' | sed "s|^|$f: |" || true
  done
  true
) && echo "DONE: Lambda functions checked" || echo "UNKNOWN: could not list Lambda functions"
