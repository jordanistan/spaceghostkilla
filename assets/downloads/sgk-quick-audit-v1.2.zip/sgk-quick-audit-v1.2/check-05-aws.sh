#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-05-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

python3 - credential-report.csv <<'EOF'
import csv, sys
with open(sys.argv[1], newline="") as f:
    for row in csv.DictReader(f, strict=True):
        if row["password_enabled"] == "true":
            print(row["user"], "created=" + row["user_creation_time"],
                  "password_last_used=" + row["password_last_used"], sep="\t")
EOF
