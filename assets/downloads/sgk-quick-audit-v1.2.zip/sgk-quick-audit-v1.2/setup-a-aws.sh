#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: setup-a-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

(
  set -euo pipefail
  umask 077
  state=""
  for attempt in $(seq 1 20); do
    state=$(aws iam generate-credential-report --query State --output text)
    [ "$state" = "COMPLETE" ] && break
    sleep 3
  done
  [ "$state" = "COMPLETE" ] || { echo "ERROR: report not ready after 60s (state: $state)" >&2; exit 1; }
  aws iam get-credential-report --query Content --output text | base64 -d > credential-report.csv
  python3 - credential-report.csv <<'EOF'
import csv, sys
need = {"user", "arn", "user_creation_time", "password_enabled", "password_last_used", "mfa_active",
        "access_key_1_active", "access_key_1_last_rotated", "access_key_1_last_used_date",
        "access_key_2_active", "access_key_2_last_rotated", "access_key_2_last_used_date"}
try:
    with open(sys.argv[1], newline="") as f:
        reader = csv.DictReader(f, strict=True)
        missing = need - set(reader.fieldnames or [])
        if missing:
            sys.exit("ERROR: not a credential report (missing " + ", ".join(sorted(missing)) + ")")
        rows = 0
        for row in reader:
            if None in row or None in row.values():
                sys.exit(f"ERROR: malformed report row at line {reader.line_num}")
            rows += 1
except csv.Error as e:
    sys.exit(f"ERROR: malformed credential report: {e}")
print(f"OK: {rows} principals in credential-report.csv")
EOF
)
