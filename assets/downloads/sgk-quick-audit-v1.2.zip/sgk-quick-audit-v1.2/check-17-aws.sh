#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-17-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

aws ec2 describe-instances \
  --query "Reservations[].Instances[?MetadataOptions.HttpTokens!='required'][].InstanceId"
