#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-05-azure.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

az rest --method get \
  --url "https://graph.microsoft.com/v1.0/users?\$select=userPrincipalName,accountEnabled,signInActivity"
