#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-04-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

python3 - credential-report.csv <<'EOF'
import csv, sys
with open(sys.argv[1], newline="") as f:
    for row in csv.DictReader(f, strict=True):
        for k in ("1", "2"):
            if row[f"access_key_{k}_active"] == "true":
                print(row["user"], f"key{k}", "rotated=" + row[f"access_key_{k}_last_rotated"],
                      "last_used=" + row[f"access_key_{k}_last_used_date"], sep="\t")
EOF
