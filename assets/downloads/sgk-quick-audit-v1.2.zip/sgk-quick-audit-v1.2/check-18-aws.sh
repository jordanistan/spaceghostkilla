#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-18-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

aws ec2 describe-addresses --query 'Addresses[].[PublicIp,InstanceId,NetworkInterfaceId]'
aws elbv2 describe-load-balancers --query "LoadBalancers[?Scheme=='internet-facing'].DNSName"
