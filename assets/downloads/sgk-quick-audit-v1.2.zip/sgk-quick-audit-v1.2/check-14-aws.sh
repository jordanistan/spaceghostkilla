#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-14-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

(
  set -o pipefail
  snaps=$(aws rds describe-db-snapshots --snapshot-type manual \
      --query 'DBSnapshots[].DBSnapshotIdentifier' --output text) || exit 1
  for s in $snaps; do
    values=$(aws rds describe-db-snapshot-attributes --db-snapshot-identifier "$s" \
        --query "DBSnapshotAttributesResult.DBSnapshotAttributes[?AttributeName=='restore'].AttributeValues[]" \
        --output text) || { echo "UNKNOWN: $s (could not read attributes)"; continue; }
    printf '%s\n' $values | grep -qx all && echo "PUBLIC: $s"
  done
  true
) && echo "DONE: RDS snapshots checked" || echo "UNKNOWN: could not list RDS snapshots"
