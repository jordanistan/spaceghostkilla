#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-16-azure.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

(
  set -o pipefail
  az network nsg list -o json | jq -r '
    .[] | .name as $nsg | .securityRules[] |
    select(.access == "Allow" and .direction == "Inbound") |
    ([.sourceAddressPrefix] + (.sourceAddressPrefixes // [])
      | map(select(. == "*" or . == "Internet" or . == "0.0.0.0/0"))) as $src |
    select($src | length > 0) |
    [$nsg, .name, .protocol,
     (if (.destinationPortRange // "") != "" then .destinationPortRange
      else (.destinationPortRanges // [] | join(",")) end),
     ($src | join(" "))] | @tsv'
) && echo "DONE: NSGs checked" || echo "UNKNOWN: could not read NSGs"
