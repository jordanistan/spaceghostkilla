#!/usr/bin/env bash
# SpaceGhostKilla // Cloud Security Quick Audit v1.2: check-16-aws.sh
# Read-only unless the PDF marks the step [STATE]. See the PDF for how to interpret output.

(
  set -o pipefail
  aws ec2 describe-security-groups --output json | jq -r '
    .SecurityGroups[] | .GroupId as $g | .IpPermissions[] |
    ([.IpRanges[]?.CidrIp | select(. == "0.0.0.0/0")]
      + [.Ipv6Ranges[]?.CidrIpv6 | select(. == "::/0")]) as $src |
    select($src | length > 0) |
    [$g, (if .IpProtocol == "-1" then "all" else .IpProtocol end),
     (.FromPort // "all"), (.ToPort // "all"), ($src | join(" "))] | @tsv'
) && echo "DONE: security groups checked" || echo "UNKNOWN: could not read security groups"
